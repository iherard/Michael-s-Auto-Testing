# SoftwareTesting_Michael-s
Automated acceptance testing of the Michael's Website using Selenium Java, testng, and chromedriver tools
